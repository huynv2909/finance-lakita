<?php
	/**
	 * Method_model
	 */
	class Method_model extends MY_Model
	{
		var $table = "payment_methods";
	}
 ?>
