<?php
	/**
	 * Mark_model
	 */
	class Mark_model extends MY_Model
	{
		var $table = "mark";
	}
 ?>
