<?php
	/**
	 * Permission_model
	 */
	class Permission_model extends MY_Model
	{
		var $table = "permissions";
	}
 ?>
