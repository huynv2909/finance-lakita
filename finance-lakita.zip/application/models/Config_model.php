<?php
	/**
	 * ActEntryType_model
	 */
	class Config_model extends MY_Model
	{
		var $table = "configs";
	}
 ?>
