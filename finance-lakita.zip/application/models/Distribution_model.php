<?php
	/**
	 * Distribution_model
	 */
	class Distribution_model extends MY_Model
	{
		var $table = "detail_act_entries";
	}
 ?>
