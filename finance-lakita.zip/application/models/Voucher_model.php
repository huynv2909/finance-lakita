<?php
   /**
    * Voucher_model
    */
   class Voucher_model extends MY_Model
   {
      var $table = 'vouchers';
   }

 ?>
