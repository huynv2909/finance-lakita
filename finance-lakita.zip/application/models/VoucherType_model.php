<?php
	/**
	 * VoucherType_model
	 */
	class VoucherType_model extends MY_Model
	{
		var $table = "voucher_type";
	}
 ?>
