<?php
	/**
	 * AccountingSystem
	 */
	class AccountingSystem extends MY_Model
	{
		var $table = "acc_system";
	}
 ?>
