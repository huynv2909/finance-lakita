<?php
	/**
	 * ActEntryType_model
	 */
	class ActEntryType_model extends MY_Model
	{
		var $table = "act_entry_type";
	}
 ?>
