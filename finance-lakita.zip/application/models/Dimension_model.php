<?php
	/**
	 * Dimension_model
	 */
	class Dimension_model extends MY_Model
	{
		var $table = "dimensional_mng";
	}
 ?>
