<?php
	/**
	 * AccountingEntry_model
	 */
	class AccountingEntry_model extends MY_Model
	{
		var $table = "accounting_entries";
	}
 ?>
