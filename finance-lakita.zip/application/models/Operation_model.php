<?php
	/**
	 * Operation_model
	 */
	class Operation_model extends MY_Model
	{
		var $table = "operations";
	}
 ?>
