<?php
	/**
	 * Provider_model
	 */
	class Provider_model extends MY_Model
	{
		var $table = "providers";
	}
 ?>
