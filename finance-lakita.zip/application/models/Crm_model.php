<?php
	/**
	 * Crm_model
	 */
	class Crm_model extends MY_Model
	{
		var $table = "crm_contacts";
	}
 ?>
