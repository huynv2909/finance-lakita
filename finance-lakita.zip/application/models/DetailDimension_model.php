<?php
	/**
	 * DetailDimension_model
	 */
	class DetailDimension_model extends MY_Model
	{
		var $table = "detail_dimensional";
	}
 ?>
