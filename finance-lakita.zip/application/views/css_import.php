<!-- Bootstrap Core CSS -->
<link href="<?php echo public_url(); ?>css/bootstrap.min.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="<?php echo public_url(); ?>css/metisMenu.min.css" rel="stylesheet">

<!-- Timeline CSS -->
<link href="<?php echo public_url(); ?>css/timeline.css" rel="stylesheet">

<!-- DataTables CSS -->
 <link href="<?php echo public_url(); ?>css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

 <!-- DataTables Responsive CSS -->
 <link href="<?php echo public_url(); ?>css/dataTables/dataTables.responsive.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo public_url(); ?>css/startmin.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="<?php echo public_url(); ?>css/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo public_url(); ?>css/font-awesome.min.css" rel="stylesheet" type="text/css">

<?php if (isset($css_files) && $css_files): ?>
   <?php foreach ($css_files as $css_name): ?>
      <link href="<?php echo public_url(); ?><?php echo $css_name; ?>.css" rel="stylesheet">
   <?php endforeach; ?>
<?php endif; ?>

<!-- My style -->
<link href="<?php echo public_url(); ?>css/build/all.css" rel="stylesheet" type="text/css">
<link href="<?php echo public_url(); ?>css/build/component.css" rel="stylesheet" type="text/css">
<link href="<?php echo public_url(); ?>css/build/screen-600.css" rel="stylesheet" type="text/css">
<link href="<?php echo public_url(); ?>css/build/screen-768.css" rel="stylesheet" type="text/css">
<link href="<?php echo public_url(); ?>css/build/screen-992.css" rel="stylesheet" type="text/css">
<link href="<?php echo public_url(); ?>css/build/screen-1200.css" rel="stylesheet" type="text/css">

<!-- Jquery confirm -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
